// Central content store for the SYSTEM UPDATE experience.
// Edit the values here to personalize copy without touching component code.

export const IDENTITY = {
  name: "Noor Mohamed",
  alias: "2Mriky",
  roles: ["AI Creator", "Graphic Designer"],
  status: "ONLINE",
  confidence: 99.8,
};

export const SKILL_BARS = [
  { label: "AI Knowledge", value: 100 },
  { label: "Prompt Engineering", value: 100 },
  { label: "Cursor", value: 100 },
  { label: "MCP", value: 100 },
  { label: "Extensions", value: 100 },
  { label: "Automation", value: 100 },
  { label: "Creativity", value: 100 },
  { label: "Coffee Consumption", value: 98 },
];

export const LIFE_BARS = [
  { label: "Outdoor Exploration", value: 2 },
  { label: "Human Interaction", value: 7 },
  { label: "New Memories", value: 4 },
];

export const KNOWN_LOCATIONS = ["Tagamoa", "El Shorouk", "El Zahraa", "Maadi"];
export const UNKNOWN_LOCATION = "Downtown Cairo";

export const AI_MESSAGE_LINES = [
  "We've analyzed your behavior.",
  "You mastered prompts.",
  "You mastered AI.",
  "You mastered Cursor.",
  "You mastered automation.",
  "You mastered every tool.",
  "But...",
  "No new real-life memories were detected.",
  "Recommendation: update human dataset.",
];

export const MISSION = {
  name: "UPDATE DATASET",
  difficulty: "Easy",
  time: "One day",
  rewards: ["Coffee", "Laptop", "New memories", "Better dataset", "Stronger friendship"],
};

export const ROUTE = {
  from: "Tagamoa",
  to: "Downtown Cairo",
};

export const COMPANION = {
  name: "Youssef Ibrahim",
  friendshipScore: 98,
  successProbability: 99,
};

export const OBJECTIVES = [
  "Leave comfort zone",
  "Buy laptop",
  "Drink coffee",
  "Roast Noor",
  "Create memories",
];

export const FINAL_QUOTE = [
  "The best AI models improve with better datasets.",
  "The best humans do too.",
];

export const EASTER_EGGS = {
  stickyNote: ["Live more.", "Prompt less."],
  coffeeCup: "Insert coffee to continue",
  consoleLogs: [
    "touch-grass@latest installed successfully.",
    "dataset_updated();",
    "npm uninstall comfort-zone",
    "npm install downtown@latest",
  ],
};
