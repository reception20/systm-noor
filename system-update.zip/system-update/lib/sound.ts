"use client";

// Lightweight synthesized sound design using the Web Audio API.
// No external audio files are required — every cue below is generated
// on the fly, so the experience works immediately after `npm install`.
// All levels are intentionally subtle per the brief ("very subtle").

let ctx: AudioContext | null = null;
let ambientNodes: { stop: () => void } | null = null;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const Ctor = window.AudioContext || (window as any).webkitAudioContext;
    if (!Ctor) return null;
    ctx = new Ctor();
  }
  if (ctx.state === "suspended") ctx.resume().catch(() => {});
  return ctx;
}

function envGain(
  audioCtx: AudioContext,
  { attack = 0.01, hold = 0.05, release = 0.15, peak = 0.06 }: Partial<{
    attack: number;
    hold: number;
    release: number;
    peak: number;
  }> = {}
) {
  const gain = audioCtx.createGain();
  const now = audioCtx.currentTime;
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(peak, now + attack);
  gain.gain.setValueAtTime(peak, now + attack + hold);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + attack + hold + release);
  return gain;
}

function tone(
  freq: number,
  opts: Partial<{
    type: OscillatorType;
    attack: number;
    hold: number;
    release: number;
    peak: number;
    glideTo: number;
  }> = {}
) {
  const audioCtx = getCtx();
  if (!audioCtx) return;
  const osc = audioCtx.createOscillator();
  osc.type = opts.type ?? "sine";
  osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
  if (opts.glideTo) {
    osc.frequency.exponentialRampToValueAtTime(
      opts.glideTo,
      audioCtx.currentTime + (opts.attack ?? 0.01) + (opts.hold ?? 0.05) + (opts.release ?? 0.15)
    );
  }
  const gain = envGain(audioCtx, opts);
  osc.connect(gain).connect(audioCtx.destination);
  osc.start();
  osc.stop(audioCtx.currentTime + (opts.attack ?? 0.01) + (opts.hold ?? 0.05) + (opts.release ?? 0.15) + 0.05);
}

export const sound = {
  /** Low, calm boot pulse for the initial startup sequence. */
  boot() {
    tone(220, { type: "sine", attack: 0.02, hold: 0.08, release: 0.4, peak: 0.045 });
    setTimeout(() => tone(330, { type: "sine", attack: 0.02, hold: 0.08, release: 0.5, peak: 0.035 }), 180);
  },
  /** Quick, clean tick for scanner sweeps and typewriter beats. */
  tick() {
    tone(1200, { type: "square", attack: 0.001, hold: 0.004, release: 0.03, peak: 0.012 });
  },
  /** Digital scanner sweep — a short rising glide. */
  scan() {
    tone(420, { type: "sawtooth", attack: 0.02, hold: 0.05, release: 0.3, peak: 0.03, glideTo: 900 });
  },
  /** Subtle warning beep for the ERROR 403 transition. */
  warning() {
    tone(660, { type: "square", attack: 0.005, hold: 0.09, release: 0.12, peak: 0.05 });
    setTimeout(() => tone(660, { type: "square", attack: 0.005, hold: 0.09, release: 0.12, peak: 0.045 }), 220);
  },
  /** Warm confirmation chime for "mission accepted". */
  confirm() {
    [523.25, 659.25, 783.99].forEach((f, i) => {
      setTimeout(() => tone(f, { type: "triangle", attack: 0.01, hold: 0.1, release: 0.4, peak: 0.045 }), i * 90);
    });
  },
  /** Bright resolution chord for the success state. */
  success() {
    [392, 523.25, 659.25, 987.77].forEach((f, i) => {
      setTimeout(() => tone(f, { type: "sine", attack: 0.02, hold: 0.2, release: 0.6, peak: 0.04 }), i * 60);
    });
  },
  /** Starts a barely-there ambient drone; call stopAmbient() to end it. */
  startAmbient() {
    const audioCtx = getCtx();
    if (!audioCtx || ambientNodes) return;
    const osc1 = audioCtx.createOscillator();
    const osc2 = audioCtx.createOscillator();
    osc1.type = "sine";
    osc2.type = "sine";
    osc1.frequency.value = 110;
    osc2.frequency.value = 165;
    const gain = audioCtx.createGain();
    gain.gain.setValueAtTime(0.0001, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.012, audioCtx.currentTime + 2);
    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(audioCtx.destination);
    osc1.start();
    osc2.start();
    ambientNodes = {
      stop: () => {
        const now = audioCtx.currentTime;
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.2);
        setTimeout(() => {
          osc1.stop();
          osc2.stop();
        }, 1300);
      },
    };
  },
  stopAmbient() {
    ambientNodes?.stop();
    ambientNodes = null;
  },
};
