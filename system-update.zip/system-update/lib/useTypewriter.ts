"use client";

import { useEffect, useState } from "react";

/**
 * Reveals a string one character at a time, like text being typed
 * into a terminal. Returns the current slice plus a `done` flag.
 */
export function useTypewriter(
  fullText: string,
  { speed = 28, startDelay = 0 }: { speed?: number; startDelay?: number } = {}
) {
  const [text, setText] = useState("");
  const [done, setDone] = useState(false);

  useEffect(() => {
    setText("");
    setDone(false);
    let i = 0;
    let interval: ReturnType<typeof setInterval>;

    const start = setTimeout(() => {
      interval = setInterval(() => {
        i += 1;
        setText(fullText.slice(0, i));
        if (i >= fullText.length) {
          clearInterval(interval);
          setDone(true);
        }
      }, speed);
    }, startDelay);

    return () => {
      clearTimeout(start);
      clearInterval(interval);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fullText, speed, startDelay]);

  return { text, done };
}

/** Plays a sequence of lines one after another, typewriter-style. */
export function useTypedSequence(
  lines: string[],
  { speed = 26, lineGap = 380, startDelay = 250 }: { speed?: number; lineGap?: number; startDelay?: number } = {}
) {
  const [resolvedLines, setResolvedLines] = useState<string[]>([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [allDone, setAllDone] = useState(false);

  useEffect(() => {
    setResolvedLines([]);
    setActiveIndex(0);
    setAllDone(false);

    let cancelled = false;
    const timers: ReturnType<typeof setTimeout>[] = [];

    function typeLine(lineIndex: number, delay: number) {
      const full = lines[lineIndex];
      let i = 0;
      const t0 = setTimeout(() => {
        const interval = setInterval(() => {
          if (cancelled) return clearInterval(interval);
          i += 1;
          setResolvedLines((prev) => {
            const next = [...prev];
            next[lineIndex] = full.slice(0, i);
            return next;
          });
          if (i >= full.length) {
            clearInterval(interval);
            if (lineIndex + 1 < lines.length) {
              setActiveIndex(lineIndex + 1);
              typeLine(lineIndex + 1, lineGap);
            } else {
              setAllDone(true);
            }
          }
        }, speed);
      }, delay);
      timers.push(t0);
    }

    typeLine(0, startDelay);

    return () => {
      cancelled = true;
      timers.forEach(clearTimeout);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lines.join("|"), speed, lineGap, startDelay]);

  return { lines: resolvedLines, activeIndex, allDone };
}
