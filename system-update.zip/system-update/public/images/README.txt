Drop Noor's portrait here as: noor.jpg

Recommended: a square-ish crop, at least 500x500px.
If this file is missing, the identity card automatically falls
back to a clean "NM" monogram, so the site still works without it.
