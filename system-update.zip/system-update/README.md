# SYSTEM UPDATE

A cinematic, "AI operating system" boot experience built as a personal
surprise for **Noor Mohamed (2Mriky)** — an AI creator and graphic designer
who mastered every AI tool in existence but hasn't updated his own
real-world dataset lately. The system walks the visitor through a full
diagnostic, flags his real-world dataset as out of date, and gently
reveals the actual mission underneath: leave the comfort zone and go
with his best friend **Youssef Ibrahim** to buy a laptop in Downtown Cairo.

Built with Next.js (App Router), TypeScript, Tailwind CSS, and Framer Motion.

## Getting started

```bash
npm install
npm run dev
```

Then open http://localhost:3000. That's it — every sound effect is
synthesized live with the Web Audio API, so there are no external
audio files to source before it works.

## Personalizing it

- **Portrait** — drop a photo at `public/images/noor.jpg`. If it's
  missing, the identity card automatically falls back to a clean "NM"
  monogram, so the site still works without it.
- **Copy & data** — every line of copy (identity fields, stat values,
  mission rewards, the route, objectives, the closing quote) lives in
  one place: `lib/data.ts`. Change values there; the UI updates itself.
- **Sound design** — all cues are generated in `lib/sound.ts` using
  the Web Audio API (oscillators + envelopes), tuned to stay subtle.
  Adjust `peak` values there to make cues louder/quieter, or swap in
  real audio files by replacing calls to `sound.*()` with an
  `<audio>` element of your own.
- **Palette & type** — tokens live in `tailwind.config.ts`
  (`colors.signal.*`, `colors.core.*`) and `app/layout.tsx` (fonts:
  Space Grotesk for display, IBM Plex Mono for terminal/data text,
  Inter for body copy).

## How the experience is structured

The whole thing is a single state machine (`components/experience/SystemExperience.tsx`)
that moves the visitor through eight stages, in order:

1. **Boot** — black screen, terminal boot sequence, "ACCESSING USER..."
2. **Scan** — face-match animation, identity card reveal
3. **Analysis** — every skill bar animates in individually, then the
   real-world stats (outdoor exploration, human interaction, new
   memories) come in low and red
4. **Alert** — the glitch into `ERROR 403 / REAL WORLD ACCESS DENIED`,
   the location breakdown, then the AI's typed message — this is the
   emotional turn, where a "system" starts sounding like a friend
5. **Mission** — the `UPDATE DATASET` mission card and accept flow
6. **Map** — a minimal glowing route from Tagamoa to Downtown Cairo
7. **Companion** — Youssef Ibrahim detected, friendship score, mission
   objectives checklist
8. **Finale** — `SYSTEM UPDATED`, the closing line, and the real
   call-to-action

A quiet dot-based progress indicator at the bottom of the screen
tracks position in that sequence throughout.

## Project structure

```
app/
  layout.tsx        Root layout, fonts, metadata
  page.tsx           Entry point — renders <SystemExperience />
  globals.css        Design tokens, glass/utility classes
components/
  experience/         One file per stage + the orchestrator
  ui/Primitives.tsx    Shared building blocks (buttons, panels, bars, particles)
lib/
  data.ts             All copy and content — edit this first
  sound.ts            Synthesized sound design
  useTypewriter.ts     Typing-effect hooks used across stages
public/
  images/              Drop noor.jpg here
```

## Notes

- Respects `prefers-reduced-motion`.
- Visible keyboard focus states throughout.
- Fully responsive, tested down to small mobile widths.
- No external services, tracking, or analytics.
