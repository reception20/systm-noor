import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        core: {
          black: "#060607",
          panel: "#0B0B0D",
          line: "rgba(255,255,255,0.08)",
        },
        signal: {
          orange: "#FF6A1A",
          amber: "#FFB347",
          bright: "#FFA94D",
          red: "#FF3B30",
        },
        ink: {
          primary: "#F5F3EF",
          muted: "#9A9893",
          faint: "#5F5D59",
        },
      },
      fontFamily: {
        display: ["var(--font-space-grotesk)", "sans-serif"],
        mono: ["var(--font-plex-mono)", "monospace"],
        body: ["var(--font-inter)", "sans-serif"],
      },
      boxShadow: {
        glow: "0 0 40px rgba(255,106,26,0.35)",
        "glow-lg": "0 0 90px rgba(255,106,26,0.28)",
        "glow-red": "0 0 60px rgba(255,59,48,0.35)",
      },
      keyframes: {
        blink: {
          "0%, 49%": { opacity: "1" },
          "50%, 100%": { opacity: "0" },
        },
        scanline: {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100%)" },
        },
        drift: {
          "0%, 100%": { transform: "translate(0,0)" },
          "50%": { transform: "translate(12px,-10px)" },
        },
      },
      animation: {
        blink: "blink 1s step-end infinite",
        scanline: "scanline 2.4s linear infinite",
        drift: "drift 9s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
export default config;
