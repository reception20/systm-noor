"use client";

import { ReactNode, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";

/* ------------------------------------------------------------------ */
/* GlassPanel — the base surface used across every stage               */
/* ------------------------------------------------------------------ */
export function GlassPanel({
  children,
  className = "",
  tilt = true,
}: {
  children: ReactNode;
  className?: string;
  tilt?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [style, setStyle] = useState<{ transform: string }>({ transform: "" });

  function onMouseMove(e: React.MouseEvent<HTMLDivElement>) {
    if (!tilt || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    setStyle({
      transform: `perspective(900px) rotateX(${(-py * 3.5).toFixed(2)}deg) rotateY(${(px * 3.5).toFixed(2)}deg)`,
    });
  }

  function onMouseLeave() {
    setStyle({ transform: "perspective(900px) rotateX(0deg) rotateY(0deg)" });
  }

  return (
    <div
      ref={ref}
      onMouseMove={onMouseMove}
      onMouseLeave={onMouseLeave}
      style={{ transform: style.transform, transition: "transform 0.35s cubic-bezier(0.2,0.8,0.2,1)" }}
      className={`glass rounded-2xl ${className}`}
    >
      {children}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* GlowButton — magnetic, glowing call-to-action                       */
/* ------------------------------------------------------------------ */
export function GlowButton({
  children,
  onClick,
  tone = "orange",
  size = "lg",
}: {
  children: ReactNode;
  onClick?: () => void;
  tone?: "orange" | "quiet";
  size?: "lg" | "md";
}) {
  const ref = useRef<HTMLButtonElement>(null);
  const [offset, setOffset] = useState({ x: 0, y: 0 });

  function onMouseMove(e: React.MouseEvent<HTMLButtonElement>) {
    if (!ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const x = (e.clientX - rect.left - rect.width / 2) * 0.28;
    const y = (e.clientY - rect.top - rect.height / 2) * 0.28;
    setOffset({ x, y });
  }

  const isOrange = tone === "orange";

  return (
    <motion.button
      ref={ref}
      onMouseMove={onMouseMove}
      onMouseLeave={() => setOffset({ x: 0, y: 0 })}
      onClick={onClick}
      animate={{ x: offset.x, y: offset.y }}
      transition={{ type: "spring", stiffness: 250, damping: 18, mass: 0.4 }}
      whileTap={{ scale: 0.96 }}
      className={[
        "group relative inline-flex items-center justify-center gap-3 rounded-full font-display font-semibold tracking-wide transition-shadow",
        size === "lg" ? "px-10 py-4 text-base md:text-lg" : "px-6 py-2.5 text-sm",
        isOrange
          ? "bg-gradient-to-b from-signal-amber to-signal-orange text-[#180a02] shadow-glow hover:shadow-glow-lg"
          : "glass text-ink-primary hover:border-signal-orange/50",
      ].join(" ")}
    >
      <span className="relative z-10">{children}</span>
      {isOrange && (
        <span className="pointer-events-none absolute inset-0 -z-0 rounded-full opacity-0 blur-xl transition-opacity duration-300 group-hover:opacity-70 bg-signal-orange" />
      )}
    </motion.button>
  );
}

/* ------------------------------------------------------------------ */
/* StatBar — a single animated readout bar                             */
/* ------------------------------------------------------------------ */
export function StatBar({
  label,
  value,
  danger = false,
  delay = 0,
}: {
  label: string;
  value: number;
  danger?: boolean;
  delay?: number;
}) {
  return (
    <div className="w-full">
      <div className="mb-1.5 flex items-baseline justify-between font-mono text-[11px] uppercase tracking-[0.14em] text-ink-muted">
        <span>{label}</span>
        <motion.span
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: delay + 0.5 }}
          className={danger ? "text-signal-red" : "text-ink-primary"}
        >
          {value}%
        </motion.span>
      </div>
      <div className="h-[3px] w-full overflow-hidden rounded-full bg-white/[0.06]">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 1.1, delay, ease: [0.16, 1, 0.3, 1] }}
          className={`h-full rounded-full ${
            danger
              ? "bg-gradient-to-r from-signal-red/70 to-signal-red"
              : "bg-gradient-to-r from-signal-amber to-signal-orange"
          }`}
        />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* CursorSpotlight — ambient glow that follows the pointer              */
/* ------------------------------------------------------------------ */
export function CursorSpotlight() {
  const [pos, setPos] = useState({ x: -400, y: -400 });

  useEffect(() => {
    function handle(e: MouseEvent) {
      setPos({ x: e.clientX, y: e.clientY });
    }
    window.addEventListener("mousemove", handle);
    return () => window.removeEventListener("mousemove", handle);
  }, []);

  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 z-0 hidden md:block"
      style={{
        background: `radial-gradient(600px circle at ${pos.x}px ${pos.y}px, rgba(255,106,26,0.06), transparent 60%)`,
      }}
    />
  );
}

/* ------------------------------------------------------------------ */
/* ParticleField — ambient drifting embers                             */
/* ------------------------------------------------------------------ */
export function ParticleField({ density = 26, intense = false }: { density?: number; intense?: boolean }) {
  const particles = useRef(
    Array.from({ length: density }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      top: Math.random() * 100,
      size: Math.random() * 2.4 + 1,
      duration: Math.random() * 6 + 6,
      delay: Math.random() * 6,
    }))
  ).current;

  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {particles.map((p) => (
        <span
          key={p.id}
          className="absolute rounded-full animate-drift"
          style={{
            left: `${p.left}%`,
            top: `${p.top}%`,
            width: p.size,
            height: p.size,
            background: intense ? "#FFB347" : "rgba(255,106,26,0.55)",
            boxShadow: intense ? "0 0 8px 2px rgba(255,179,71,0.6)" : "0 0 6px rgba(255,106,26,0.4)",
            animationDuration: `${p.duration}s`,
            animationDelay: `${p.delay}s`,
            opacity: intense ? 0.85 : 0.45,
          }}
        />
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* BlinkingCursor — terminal caret                                     */
/* ------------------------------------------------------------------ */
export function BlinkingCursor({ className = "" }: { className?: string }) {
  return <span className={`inline-block w-[9px] translate-y-[1px] bg-signal-orange animate-blink ${className}`} style={{ height: "1em" }} />;
}

/* ------------------------------------------------------------------ */
/* StageProgress — a real sequence indicator (this boot has real order) */
/* ------------------------------------------------------------------ */
export function StageProgress({ total, current }: { total: number; current: number }) {
  return (
    <div className="fixed bottom-6 left-1/2 z-40 flex -translate-x-1/2 gap-1.5">
      {Array.from({ length: total }, (_, i) => (
        <span
          key={i}
          className={`h-[3px] rounded-full transition-all duration-500 ${
            i === current ? "w-6 bg-signal-orange" : i < current ? "w-3 bg-signal-orange/40" : "w-3 bg-white/10"
          }`}
        />
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Continue — small quiet affordance to advance a stage manually       */
/* ------------------------------------------------------------------ */
export function ContinueHint({ onClick, label = "Continue" }: { onClick: () => void; label?: string }) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={onClick}
      className="group mt-10 flex items-center gap-2 font-mono text-xs uppercase tracking-[0.2em] text-ink-muted transition-colors hover:text-signal-orange"
    >
      {label}
      <span className="transition-transform group-hover:translate-x-1">→</span>
    </motion.button>
  );
}
