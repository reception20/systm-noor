"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { GlassPanel, ContinueHint, StageProgress, StatBar } from "@/components/ui/Primitives";
import { COMPANION, OBJECTIVES } from "@/lib/data";
import { sound } from "@/lib/sound";

export default function StageCompanion({
  onDone,
  index,
  total,
}: {
  onDone: () => void;
  index: number;
  total: number;
}) {
  const [phase, setPhase] = useState<"scanning" | "found" | "objectives">("scanning");
  const [checked, setChecked] = useState(0);

  useEffect(() => {
    sound.scan();
    const t = setTimeout(() => setPhase("found"), 1500);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (phase !== "objectives") return;
    let i = 0;
    const interval = setInterval(() => {
      i += 1;
      setChecked(i);
      sound.tick();
      if (i >= OBJECTIVES.length) clearInterval(interval);
    }, 260);
    return () => clearInterval(interval);
  }, [phase]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="relative flex min-h-screen w-full items-center justify-center bg-core-black bg-grid px-6 py-20"
    >
      <StageProgress total={total} current={index} />

      <AnimatePresence mode="wait">
        {phase === "scanning" && (
          <motion.p
            key="scanning"
            exit={{ opacity: 0 }}
            className="font-mono text-sm uppercase tracking-[0.22em] text-ink-muted"
          >
            Scanning for nearby companions...
          </motion.p>
        )}

        {phase === "found" && (
          <motion.div key="found" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="w-full max-w-md">
            <GlassPanel className="p-8 md:p-10">
              <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-signal-amber">Companion found</p>
              <h2 className="mt-2 font-display text-2xl font-semibold text-ink-primary md:text-3xl">
                {COMPANION.name}
              </h2>

              <div className="mt-6 space-y-4">
                <StatBar label="Friendship score" value={COMPANION.friendshipScore} delay={0.1} />
                <StatBar label="Mission success probability" value={COMPANION.successProbability} delay={0.3} />
              </div>

              <ContinueHint onClick={() => setPhase("objectives")} label="View objectives" />
            </GlassPanel>
          </motion.div>
        )}

        {phase === "objectives" && (
          <motion.div key="objectives" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
            <GlassPanel className="p-8 md:p-10">
              <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-ink-muted">Mission objectives</p>
              <ul className="mt-5 space-y-3">
                {OBJECTIVES.map((obj, i) => (
                  <li key={obj} className="flex items-center gap-3 text-sm text-ink-primary">
                    <span
                      className={`flex h-5 w-5 shrink-0 items-center justify-center rounded border text-[11px] transition-colors ${
                        i < checked ? "border-signal-orange bg-signal-orange/20 text-signal-orange" : "border-white/15 text-transparent"
                      }`}
                    >
                      ✓
                    </span>
                    <span className={i < checked ? "text-ink-primary" : "text-ink-faint"}>{obj}</span>
                  </li>
                ))}
              </ul>

              {checked >= OBJECTIVES.length && <ContinueHint onClick={onDone} label="Finalize update" />}
            </GlassPanel>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
