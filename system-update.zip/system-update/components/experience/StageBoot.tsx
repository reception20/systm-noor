"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useTypewriter } from "@/lib/useTypewriter";
import { BlinkingCursor } from "@/components/ui/Primitives";
import { sound } from "@/lib/sound";

export default function StageBoot({ onDone }: { onDone: () => void }) {
  const [phase, setPhase] = useState<"init" | "loading" | "access" | "leave">("init");
  const { text: initText, done: initDone } = useTypewriter("INITIALIZING AI CORE...", { speed: 34, startDelay: 900 });
  const { text: accessText, done: accessDone } = useTypewriter("ACCESSING USER...", {
    speed: 34,
    startDelay: 200,
  });
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    sound.boot();
  }, []);

  useEffect(() => {
    if (initDone && phase === "init") {
      const t = setTimeout(() => setPhase("loading"), 260);
      return () => clearTimeout(t);
    }
  }, [initDone, phase]);

  useEffect(() => {
    if (phase !== "loading") return;
    const start = Date.now();
    const duration = 1500;
    const raf = () => {
      const p = Math.min(1, (Date.now() - start) / duration);
      setProgress(p);
      if (p < 1) requestAnimationFrame(raf);
      else setTimeout(() => setPhase("access"), 350);
    };
    requestAnimationFrame(raf);
  }, [phase]);

  useEffect(() => {
    if (phase === "access" && accessDone) {
      const t = setTimeout(() => setPhase("leave"), 700);
      return () => clearTimeout(t);
    }
  }, [phase, accessDone]);

  useEffect(() => {
    if (phase === "leave") {
      const t = setTimeout(onDone, 500);
      return () => clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase]);

  return (
    <AnimatePresence>
      {phase !== "leave" && (
        <motion.div
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-core-black"
        >
          <div className="w-full max-w-md px-8 font-mono text-sm text-ink-primary">
            <p className="min-h-[1.5em]">
              {initText}
              {!initDone && <BlinkingCursor />}
            </p>

            {(phase === "loading" || phase === "access") && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-4">
                <div className="h-[2px] w-full overflow-hidden rounded-full bg-white/10">
                  <motion.div
                    className="h-full bg-gradient-to-r from-signal-amber to-signal-orange"
                    style={{ width: `${Math.min(progress, 1) * 100}%` }}
                  />
                </div>
                <p className="mt-1.5 text-[11px] tracking-[0.2em] text-ink-faint">
                  {Math.round(Math.min(progress, 1) * 100).toString().padStart(3, "0")}%
                </p>
              </motion.div>
            )}

            {phase === "access" && (
              <p className="mt-6 min-h-[1.5em] text-signal-amber">
                {accessText}
                {!accessDone && <BlinkingCursor className="bg-signal-amber" />}
              </p>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
