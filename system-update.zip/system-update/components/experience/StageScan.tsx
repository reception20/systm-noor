"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { GlassPanel, ContinueHint, StageProgress } from "@/components/ui/Primitives";
import { IDENTITY } from "@/lib/data";
import { sound } from "@/lib/sound";

const FIELDS: [string, string][] = [
  ["Name", IDENTITY.name],
  ["Alias", IDENTITY.alias],
  ["Role", IDENTITY.roles.join(" / ")],
  ["Status", IDENTITY.status],
  ["Confidence", `${IDENTITY.confidence}%`],
];

export default function StageScan({
  onDone,
  index,
  total,
}: {
  onDone: () => void;
  index: number;
  total: number;
}) {
  const [scanProgress, setScanProgress] = useState(0);
  const [matched, setMatched] = useState(false);
  const [imgError, setImgError] = useState(false);
  const [visibleFields, setVisibleFields] = useState(0);

  useEffect(() => {
    sound.scan();
    const start = Date.now();
    const duration = 2200;
    const raf = () => {
      const p = Math.min(1, (Date.now() - start) / duration);
      setScanProgress(p);
      if (p < 1) requestAnimationFrame(raf);
      else setMatched(true);
    };
    requestAnimationFrame(raf);
  }, []);

  useEffect(() => {
    if (!matched) return;
    sound.tick();
    let i = 0;
    const interval = setInterval(() => {
      i += 1;
      setVisibleFields(i);
      sound.tick();
      if (i >= FIELDS.length) clearInterval(interval);
    }, 220);
    return () => clearInterval(interval);
  }, [matched]);

  const barLength = 22;
  const filled = Math.round(scanProgress * barLength);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
      className="relative flex min-h-screen w-full items-center justify-center bg-core-black bg-grid px-6 py-20"
    >
      <StageProgress total={total} current={index} />
      <GlassPanel className="w-full max-w-md p-8" tilt>
        <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-ink-muted">
          {matched ? "Identity confirmed" : "Scanning user..."}
        </p>

        <div className="relative mx-auto mt-6 h-44 w-44 overflow-hidden rounded-xl border border-white/10 bg-white/[0.03]">
          {!imgError ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src="/images/noor.jpg"
              alt="Noor Mohamed"
              onError={() => setImgError(true)}
              className="h-full w-full object-cover"
              style={{ filter: matched ? "none" : "grayscale(1) contrast(1.1)" }}
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-white/[0.06] to-transparent font-display text-4xl text-signal-orange/70">
              NM
            </div>
          )}

          {!matched && (
            <motion.div
              className="absolute inset-x-0 h-10 bg-gradient-to-b from-signal-orange/0 via-signal-orange/40 to-signal-orange/0"
              animate={{ top: ["-10%", "100%"] }}
              transition={{ duration: 1.4, repeat: Infinity, ease: "linear" }}
            />
          )}

          {matched && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="absolute inset-0 rounded-xl ring-1 ring-signal-orange/60 shadow-glow"
            />
          )}
        </div>

        {!matched ? (
          <div className="mt-6 font-mono text-[11px] text-ink-muted">
            <p className="text-signal-orange/80">
              {"█".repeat(filled)}
              <span className="text-white/10">{"█".repeat(barLength - filled)}</span>
            </p>
            <p className="mt-2 tracking-[0.15em]">Face match {Math.round(scanProgress * 100)}%</p>
          </div>
        ) : (
          <dl className="mt-6 space-y-2.5">
            {FIELDS.map(([label, value], i) => (
              <motion.div
                key={label}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: i < visibleFields ? 1 : 0, x: i < visibleFields ? 0 : -8 }}
                className="flex items-baseline justify-between border-b border-white/[0.06] pb-2 font-mono text-xs"
              >
                <dt className="uppercase tracking-[0.16em] text-ink-faint">{label}</dt>
                <dd className={label === "Status" ? "text-signal-amber" : "text-ink-primary"}>{value}</dd>
              </motion.div>
            ))}
          </dl>
        )}

        {matched && visibleFields >= FIELDS.length && <ContinueHint onClick={onDone} />}
      </GlassPanel>
    </motion.div>
  );
}
