"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { StageProgress, ContinueHint } from "@/components/ui/Primitives";
import { ROUTE } from "@/lib/data";
import { sound } from "@/lib/sound";

const PATH_D = "M 60 260 C 160 60, 340 340, 460 90";

export default function StageMap({
  onDone,
  index,
  total,
}: {
  onDone: () => void;
  index: number;
  total: number;
}) {
  const [arrived, setArrived] = useState(false);

  useEffect(() => {
    sound.scan();
    const t = setTimeout(() => {
      setArrived(true);
      sound.tick();
    }, 2600);
    return () => clearTimeout(t);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="relative flex min-h-screen w-full flex-col items-center justify-center bg-core-black bg-grid px-6 py-20"
    >
      <StageProgress total={total} current={index} />

      <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-ink-muted">Route plotted</p>
      <h2 className="mt-2 text-center font-display text-2xl font-semibold text-ink-primary md:text-3xl">
        {ROUTE.from} &nbsp;→&nbsp; {ROUTE.to}
      </h2>

      <div className="relative mt-10 w-full max-w-xl">
        <svg viewBox="0 0 520 360" className="w-full" aria-hidden>
          <defs>
            <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#FFB347" />
              <stop offset="100%" stopColor="#FF6A1A" />
            </linearGradient>
            <radialGradient id="nodeGlow">
              <stop offset="0%" stopColor="#FF6A1A" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#FF6A1A" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* faint grid dots for a "minimal futuristic map" texture */}
          {Array.from({ length: 12 }).map((_, r) =>
            Array.from({ length: 16 }).map((_, c) => (
              <circle key={`${r}-${c}`} cx={c * 36 + 10} cy={r * 34 + 12} r={1} fill="rgba(255,255,255,0.06)" />
            ))
          )}

          <motion.path
            d={PATH_D}
            fill="none"
            stroke="url(#routeGradient)"
            strokeWidth={2}
            strokeLinecap="round"
            strokeDasharray="1 7"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 0.9 }}
            transition={{ duration: 2.2, ease: "easeInOut" }}
          />

          <circle cx={60} cy={260} r={26} fill="url(#nodeGlow)" />
          <circle cx={60} cy={260} r={5} fill="#FFB347" />
          <text x={60} y={296} textAnchor="middle" fill="#9A9893" fontSize="12" fontFamily="var(--font-plex-mono)">
            {ROUTE.from}
          </text>

          <circle cx={460} cy={90} r={30} fill="url(#nodeGlow)" />
          <circle cx={460} cy={90} r={6} fill={arrived ? "#FFA94D" : "#5F5D59"} />
          <text x={460} y={64} textAnchor="middle" fill={arrived ? "#FFA94D" : "#9A9893"} fontSize="12" fontFamily="var(--font-plex-mono)">
            {ROUTE.to}
          </text>
        </svg>

        <motion.div
          className="absolute h-3 w-3 rounded-full bg-signal-amber shadow-glow"
          style={{ offsetPath: `path('${PATH_D}')` } as React.CSSProperties}
          initial={{ offsetDistance: "0%" as any, opacity: 0 }}
          animate={{ offsetDistance: "100%" as any, opacity: 1 }}
          transition={{ duration: 2.4, ease: "easeInOut", delay: 0.1 }}
        />
      </div>

      {arrived && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mt-2 font-mono text-xs uppercase tracking-[0.2em] text-signal-amber"
        >
          Destination reached
        </motion.p>
      )}

      {arrived && <ContinueHint onClick={onDone} label="Scan for companion" />}
    </motion.div>
  );
}
