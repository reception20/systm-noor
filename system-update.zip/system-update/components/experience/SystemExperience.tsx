"use client";

import { useCallback, useEffect, useState } from "react";
import { AnimatePresence } from "framer-motion";
import StageBoot from "./StageBoot";
import StageScan from "./StageScan";
import StageAnalysis from "./StageAnalysis";
import StageAlert from "./StageAlert";
import StageMission from "./StageMission";
import StageMap from "./StageMap";
import StageCompanion from "./StageCompanion";
import StageFinale from "./StageFinale";
import { CursorSpotlight } from "@/components/ui/Primitives";
import { sound } from "@/lib/sound";

const STAGE_ORDER = [
  "boot",
  "scan",
  "analysis",
  "alert",
  "mission",
  "map",
  "companion",
  "finale",
] as const;

type Stage = (typeof STAGE_ORDER)[number];

export default function SystemExperience() {
  const [stage, setStage] = useState<Stage>("boot");
  const stageIndex = STAGE_ORDER.indexOf(stage);

  const goTo = useCallback((next: Stage) => {
    setStage(next);
  }, []);

  // Soft ambient bed starts once the visitor is inside the experience
  // (after boot) and stops on the finale, where the success chord takes over.
  useEffect(() => {
    if (stage !== "boot" && stage !== "finale") {
      sound.startAmbient();
    } else {
      sound.stopAmbient();
    }
    return () => sound.stopAmbient();
  }, [stage]);

  function restart() {
    sound.stopAmbient();
    setStage("boot");
  }

  return (
    <main className="relative min-h-screen w-full bg-core-black">
      <CursorSpotlight />
      <AnimatePresence mode="wait">
        {stage === "boot" && <StageBoot key="boot" onDone={() => goTo("scan")} />}
        {stage === "scan" && (
          <StageScan key="scan" index={stageIndex} total={STAGE_ORDER.length} onDone={() => goTo("analysis")} />
        )}
        {stage === "analysis" && (
          <StageAnalysis key="analysis" index={stageIndex} total={STAGE_ORDER.length} onDone={() => goTo("alert")} />
        )}
        {stage === "alert" && (
          <StageAlert key="alert" index={stageIndex} total={STAGE_ORDER.length} onDone={() => goTo("mission")} />
        )}
        {stage === "mission" && (
          <StageMission key="mission" index={stageIndex} total={STAGE_ORDER.length} onDone={() => goTo("map")} />
        )}
        {stage === "map" && (
          <StageMap key="map" index={stageIndex} total={STAGE_ORDER.length} onDone={() => goTo("companion")} />
        )}
        {stage === "companion" && (
          <StageCompanion
            key="companion"
            index={stageIndex}
            total={STAGE_ORDER.length}
            onDone={() => goTo("finale")}
          />
        )}
        {stage === "finale" && (
          <StageFinale key="finale" index={stageIndex} total={STAGE_ORDER.length} onRestart={restart} />
        )}
      </AnimatePresence>
    </main>
  );
}
