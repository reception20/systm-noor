"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { GlassPanel, GlowButton, StageProgress, BlinkingCursor } from "@/components/ui/Primitives";
import { MISSION } from "@/lib/data";
import { useTypedSequence } from "@/lib/useTypewriter";
import { sound } from "@/lib/sound";

const EXEC_LINES = ["Executing...", "Updating human dataset...", "Loading..."];

export default function StageMission({
  onDone,
  index,
  total,
}: {
  onDone: () => void;
  index: number;
  total: number;
}) {
  const [phase, setPhase] = useState<"card" | "executing">("card");
  const { lines, allDone } = useTypedSequence(EXEC_LINES, { speed: 26, lineGap: 420, startDelay: 150 });

  function accept() {
    sound.confirm();
    setPhase("executing");
  }

  useEffect(() => {
    if (phase === "executing" && allDone) {
      const t = setTimeout(onDone, 700);
      return () => clearTimeout(t);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, allDone]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="relative flex min-h-screen w-full items-center justify-center bg-core-black bg-grid px-6 py-20"
    >
      <StageProgress total={total} current={index} />

      <AnimatePresence mode="wait">
        {phase === "card" ? (
          <motion.div key="card" exit={{ opacity: 0, y: -10 }} className="w-full max-w-md">
            <GlassPanel className="p-8 md:p-10">
              <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-signal-amber">Mission available</p>
              <h2 className="mt-2 font-display text-3xl font-semibold text-ink-primary">{MISSION.name}</h2>

              <div className="mt-6 grid grid-cols-2 gap-4 font-mono text-xs">
                <div>
                  <p className="text-ink-faint uppercase tracking-[0.16em]">Difficulty</p>
                  <p className="mt-1 text-ink-primary">{MISSION.difficulty}</p>
                </div>
                <div>
                  <p className="text-ink-faint uppercase tracking-[0.16em]">Estimated time</p>
                  <p className="mt-1 text-ink-primary">{MISSION.time}</p>
                </div>
              </div>

              <div className="mt-6">
                <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-faint">Rewards</p>
                <ul className="mt-2 grid grid-cols-1 gap-1.5">
                  {MISSION.rewards.map((r) => (
                    <li key={r} className="flex items-center gap-2 text-sm text-ink-primary">
                      <span className="text-signal-orange">+</span> {r}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-8 flex justify-center">
                <GlowButton onClick={accept}>Accept mission</GlowButton>
              </div>
            </GlassPanel>
          </motion.div>
        ) : (
          <motion.div
            key="executing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="w-full max-w-md font-mono text-sm text-ink-primary"
          >
            {EXEC_LINES.map((full, i) => (
              <p key={i} className="min-h-[1.6em] text-signal-amber">
                {lines[i] ?? ""}
                {lines[i] !== undefined && lines[i].length < full.length && <BlinkingCursor className="bg-signal-amber" />}
              </p>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
