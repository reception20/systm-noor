"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { GlassPanel, GlowButton, ParticleField, StageProgress } from "@/components/ui/Primitives";
import { FINAL_QUOTE, EASTER_EGGS } from "@/lib/data";
import { sound } from "@/lib/sound";

export default function StageFinale({
  onRestart,
  index,
  total,
}: {
  onRestart: () => void;
  index: number;
  total: number;
}) {
  const [launched, setLaunched] = useState(false);

  useEffect(() => {
    sound.success();
    EASTER_EGGS.consoleLogs.slice(0, 2).forEach((line, i) => {
      setTimeout(() => console.log(`%c${line}`, "color:#FF6A1A"), i * 400);
    });
  }, []);

  function launch() {
    setLaunched(true);
    sound.confirm();
    EASTER_EGGS.consoleLogs.slice(2).forEach((line, i) => {
      setTimeout(() => console.log(`%c${line}`, "color:#FFB347"), i * 350);
    });
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="relative flex min-h-screen w-full items-center justify-center overflow-hidden bg-core-black px-6 py-20"
    >
      <StageProgress total={total} current={index} />
      <ParticleField density={46} intense />

      {/* decorative easter eggs */}
      <motion.div
        initial={{ opacity: 0, rotate: -6 }}
        animate={{ opacity: 1, rotate: -6 }}
        transition={{ delay: 0.6 }}
        className="absolute left-6 top-24 hidden w-32 rounded-sm bg-signal-amber/90 p-3 font-mono text-[11px] leading-tight text-[#241000] shadow-lg md:block"
      >
        {EASTER_EGGS.stickyNote.map((l) => (
          <p key={l}>{l}</p>
        ))}
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.8 }}
        transition={{ delay: 0.8 }}
        className="absolute bottom-16 right-8 hidden font-mono text-[11px] text-ink-faint md:block"
      >
        ☕ {EASTER_EGGS.coffeeCup}
      </motion.div>

      <GlassPanel className="relative z-10 w-full max-w-lg p-10 text-center">
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="font-mono text-[11px] uppercase tracking-[0.24em] text-signal-amber"
        >
          System updated
        </motion.p>
        <h1 className="mt-3 font-display text-3xl font-bold text-ink-primary text-glow md:text-4xl">
          Congratulations.
        </h1>
        <p className="mt-2 font-display text-xl text-ink-primary/90 md:text-2xl">
          You are becoming human again.
        </p>

        <div className="mx-auto my-8 h-px w-16 bg-signal-orange/40" />

        <p className="font-body text-sm leading-relaxed text-ink-muted md:text-base">
          {FINAL_QUOTE[0]}
          <br />
          {FINAL_QUOTE[1]}
        </p>

        <div className="mt-9 flex justify-center">
          {!launched ? (
            <GlowButton onClick={launch}>Start mission</GlowButton>
          ) : (
            <motion.p
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              className="font-mono text-sm text-signal-amber"
            >
              Mission live. See you in Downtown Cairo. 🧡
            </motion.p>
          )}
        </div>

        {launched && (
          <button
            onClick={onRestart}
            className="mt-8 font-mono text-[11px] uppercase tracking-[0.18em] text-ink-faint transition-colors hover:text-signal-orange"
          >
            Replay boot sequence
          </button>
        )}
      </GlassPanel>
    </motion.div>
  );
}
