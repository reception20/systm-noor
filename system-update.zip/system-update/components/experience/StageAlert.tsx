"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { GlassPanel, ContinueHint, StageProgress, BlinkingCursor } from "@/components/ui/Primitives";
import { KNOWN_LOCATIONS, UNKNOWN_LOCATION, AI_MESSAGE_LINES } from "@/lib/data";
import { useTypedSequence } from "@/lib/useTypewriter";
import { sound } from "@/lib/sound";

type Phase = "glitch" | "details" | "message";

export default function StageAlert({
  onDone,
  index,
  total,
}: {
  onDone: () => void;
  index: number;
  total: number;
}) {
  const [phase, setPhase] = useState<Phase>("glitch");
  const { lines, allDone } = useTypedSequence(AI_MESSAGE_LINES, {
    speed: 22,
    lineGap: 340,
    startDelay: 300,
  });

  useEffect(() => {
    sound.warning();
    const t = setTimeout(() => setPhase("details"), 2100);
    return () => clearTimeout(t);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="relative flex min-h-screen w-full items-center justify-center overflow-hidden bg-core-black px-6 py-20"
    >
      <StageProgress total={total} current={index} />

      {/* ambient danger wash */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        initial={{ background: "radial-gradient(circle at 50% 40%, rgba(255,106,26,0.12), transparent 60%)" }}
        animate={{
          background:
            phase === "glitch"
              ? [
                  "radial-gradient(circle at 50% 40%, rgba(255,106,26,0.12), transparent 60%)",
                  "radial-gradient(circle at 50% 40%, rgba(255,59,48,0.22), transparent 60%)",
                  "radial-gradient(circle at 50% 40%, rgba(255,106,26,0.12), transparent 60%)",
                ]
              : "radial-gradient(circle at 50% 40%, rgba(255,59,48,0.14), transparent 60%)",
        }}
        transition={{ duration: 0.5, repeat: phase === "glitch" ? 3 : 0 }}
      />

      <AnimatePresence mode="wait">
        {phase === "glitch" && (
          <motion.div
            key="glitch"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="relative z-10 text-center"
          >
            <motion.h1
              animate={{ x: [0, -6, 5, -3, 0], skewX: [0, 4, -3, 2, 0] }}
              transition={{ duration: 0.6, repeat: 3 }}
              className="font-display text-5xl font-bold text-signal-red text-glow md:text-7xl"
            >
              ERROR 403
            </motion.h1>
            <p className="mt-4 font-mono text-sm uppercase tracking-[0.3em] text-ink-muted md:text-base">
              Real world access denied
            </p>
          </motion.div>
        )}

        {phase === "details" && (
          <motion.div
            key="details"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="relative z-10 w-full max-w-md"
          >
            <GlassPanel className="border-signal-red/20 p-8">
              <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-signal-red">Error details</p>
              <p className="mt-3 text-sm leading-relaxed text-ink-muted">
                Reason: user has remained inside the same geographic dataset for an extended period.
              </p>

              <div className="mt-6">
                <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-ink-faint">Known locations</p>
                <ul className="mt-2 space-y-1.5">
                  {KNOWN_LOCATIONS.map((loc) => (
                    <li key={loc} className="flex items-center gap-2 font-mono text-sm text-ink-primary">
                      <span className="text-signal-amber">✔</span> {loc}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="mt-5">
                <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-ink-faint">Unknown location</p>
                <p className="mt-2 flex items-center gap-2 font-mono text-sm text-signal-red">
                  <span>✕</span> {UNKNOWN_LOCATION}
                </p>
              </div>

              <ContinueHint onClick={() => setPhase("message")} label="Read analysis" />
            </GlassPanel>
          </motion.div>
        )}

        {phase === "message" && (
          <motion.div
            key="message"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="relative z-10 w-full max-w-lg"
          >
            <GlassPanel className="p-8 md:p-10">
              <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-ink-muted">AI message</p>
              <div className="mt-5 space-y-2 font-display text-lg leading-snug text-ink-primary md:text-xl">
                {AI_MESSAGE_LINES.map((full, i) => (
                  <p key={i} className={full === "But..." ? "text-signal-orange" : ""}>
                    {lines[i] ?? ""}
                    {lines[i] !== undefined && lines[i].length < full.length && <BlinkingCursor />}
                  </p>
                ))}
              </div>
              {allDone && <ContinueHint onClick={onDone} label="View mission" />}
            </GlassPanel>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
