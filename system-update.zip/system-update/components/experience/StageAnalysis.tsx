"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { GlassPanel, StatBar, ContinueHint, StageProgress } from "@/components/ui/Primitives";
import { SKILL_BARS, LIFE_BARS } from "@/lib/data";

export default function StageAnalysis({
  onDone,
  index,
  total,
}: {
  onDone: () => void;
  index: number;
  total: number;
}) {
  const allBars = [...SKILL_BARS, ...LIFE_BARS];
  const totalDuration = allBars.length * 0.09 + 1.1;
  const [showContinue, setShowContinue] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setShowContinue(true), totalDuration * 1000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
      className="relative flex min-h-screen w-full items-center justify-center bg-core-black bg-grid px-6 py-20"
    >
      <StageProgress total={total} current={index} />
      <GlassPanel className="w-full max-w-lg p-8 md:p-10" tilt>
        <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-ink-muted">System analysis</p>
        <h2 className="mt-2 font-display text-2xl font-semibold text-ink-primary md:text-3xl">
          Dataset breakdown
        </h2>

        <div className="mt-8 space-y-4">
          {SKILL_BARS.map((bar, i) => (
            <StatBar key={bar.label} label={bar.label} value={bar.value} delay={i * 0.09} />
          ))}
        </div>

        <div className="my-7 h-px w-full bg-white/[0.07]" />

        <div className="space-y-4">
          {LIFE_BARS.map((bar, i) => (
            <StatBar
              key={bar.label}
              label={bar.label}
              value={bar.value}
              danger
              delay={SKILL_BARS.length * 0.09 + i * 0.09}
            />
          ))}
        </div>

        {showContinue && <ContinueHint onClick={onDone} label="Run diagnostic" />}
      </GlassPanel>
    </motion.div>
  );
}
