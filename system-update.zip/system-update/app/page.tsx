import SystemExperience from "@/components/experience/SystemExperience";

export default function Home() {
  return <SystemExperience />;
}
